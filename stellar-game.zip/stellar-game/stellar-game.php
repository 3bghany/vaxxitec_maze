<?php
/**
 * Plugin Name:Stellar Game
 * Description: Plugin to build a backend api for stellar game.
 * Version:1.0
 * Auther:Abdelghany
 */
if (!defined('ABSPATH')) exit;

// Include the API class file
require_once plugin_dir_path(__FILE__) . 'includes/class-stellar-game-api.php';
require_once ABSPATH . 'vendor/autoload.php';


 function stellar_game_plugin_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'leaderboard';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        time VARCHAR(100) NOT NULL,
        totalSeconds INT NOT NULL ,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

 register_activation_hook(__FILE__, 'stellar_game_plugin_activate');