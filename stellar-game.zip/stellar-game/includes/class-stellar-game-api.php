<?php
use WebSocket\Client;
if(!defined('ABSPATH')) exit;

class Stellar_Game_API{

    public function __construct()
    {
        add_action('rest_api_init',[$this,'register_routes']);
    }

    public function register_routes(){
        register_rest_route('stellar/v1','/leaderboard',[
            'methods'=>'GET',
            'callback'=> [$this,'get_leaderboard'],
        ]);
        register_rest_route('stellar/v1','/leaderboard',[
            'methods'=>'POST',
            'callback'=> [$this,'add_leaderboard_data'],
        ]);
    }

    public function get_leaderboard(){
        global $wpdb;
        $table_name= $wpdb->prefix . 'leaderboard';
        $leaderboard=$wpdb->get_results("SELECT * FROM $table_name ORDER BY totalSeconds DESC");
        return rest_ensure_response($leaderboard);
    }

    public function add_leaderboard_data($request){
        global $wpdb;
        $table_name=$wpdb->prefix . 'leaderboard';

         // Retrieve parameters from the request
         $name = sanitize_text_field($request->get_param('name'));
         $time = sanitize_text_field($request->get_param('time'));
         $totalSeconds = intval($request->get_param('totalSeconds'));
        // validate data
         if(empty($name) || strlen($name) > 100){
            return new WP_REST_Response('valid name must be string between 1 and 100 charcters only', 400);
         }elseif(!preg_match("/^([0-9]{1,2}h\s[0-9]{1,2}m\s[0-9]{1,2}s)$/",$time)){
            return new WP_REST_Response('time data is required in only 00h 00m 00s format', 400);
         }elseif($totalSeconds <= 0 || $totalSeconds > 86400){         // i think 86400 is reasonable range (=24h) any way it depends on the bussiness logic.
            return new WP_REST_Response('totalSeconds data is invalid', 400);
         }

         $leaderboard=$wpdb->insert($table_name,[
            'name'=>$name,
            'time'=>$time,
            'totalSeconds'=>$totalSeconds,
         ],['%s','%s','%d']);// the third parameter is important for the SQL injection so it's defining the datatypes for each attr
         $created_at = current_time('mysql');
         if ($leaderboard) {
            
            try {
                // Send a WebSocket notification directly
                $client = new Client("ws://localhost:8080");
                $client->send(json_encode([
                    'id'=> $wpdb->insert_id,
                    'name' => $name,
                    'time' => $time,
                    'totalSeconds' => $totalSeconds,
                    'created_at'=>$created_at
                ]));
            } catch (Exception $e) {
                return new WP_REST_Response('Failed to notify WebSocket server: ' . $e->getMessage(), 500);
            }

            return new WP_REST_Response('Data added successfully', 201);
        } else {
            return new WP_REST_Response('Failed to add data', 500);
        }
        
    }

}

new Stellar_Game_API();